package com.neartalk

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val perms = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val ask = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }.values.all { it }
        if (ok) ContextCompat.startForegroundService(this, Intent(this, MeshService::class.java))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Crypto.init(this)
        Mesh.attach(this)
        Gateway.attach(this)
        ask.launch(perms)
        setContent { App() }
    }
}

// Colours from the prototype. Text uses the phone's native system font.
class Pal(val bg: Color, val surface: Color, val ink: Color, val mute: Color, val line: Color,
          val accent: Color, val onAccent: Color, val mine: Color, val theirs: Color, val hop: Color, val ok: Color)

private val Light = Pal(Color(0xFFEEF4F5), Color.White, Color(0xFF10303B), Color(0xFF587681), Color(0xFFD6E2E5),
    Color(0xFF0B7A8F), Color.White, Color(0xFF0B7A8F), Color.White, Color(0xFFB86A00), Color(0xFF1F8A5B))
private val Dark = Pal(Color(0xFF0A181F), Color(0xFF11242D), Color(0xFFE6F1F4), Color(0xFF8FA9B2), Color(0xFF1F3944),
    Color(0xFF35B6CC), Color(0xFF06222A), Color(0xFF176F7E), Color(0xFF173440), Color(0xFFF0A43A), Color(0xFF4FD39A))

@Composable fun pal() = if (isSystemInDarkTheme()) Dark else Light

@Composable
fun App() {
    var open by remember { mutableStateOf<String?>(null) }
    val id = open
    Box(Modifier.fillMaxSize().background(pal().bg)) {
        if (id == null) Home { open = it } else Chat(id) { open = null }
    }
}

fun hopLabel(h: Int) = when (h) { 0 -> "Remote"; 1 -> "Direct"; else -> "$h hops" }

@Composable
fun fieldColors(p: Pal) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = p.ink, unfocusedTextColor = p.ink,
    focusedBorderColor = p.accent, unfocusedBorderColor = p.line, cursorColor = p.accent,
    focusedContainerColor = p.bg, unfocusedContainerColor = p.bg)

@Composable
fun Dot() { Box(Modifier.size(9.dp).background(pal().ok, CircleShape)) }

@Composable
fun Home(onOpen: (String) -> Unit) {
    val p = pal()
    var showMine by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())) {
        Column(Modifier.fillMaxWidth().background(p.surface).padding(16.dp, 14.dp, 16.dp, 12.dp)) {
            Text("NearTalk", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Dot(); Spacer(Modifier.width(8.dp))
                Text("${Mesh.linked.value} phones linked nearby", color = p.mute, fontSize = 13.sp)
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
        Column(Modifier.padding(16.dp, 12.dp).fillMaxWidth()
            .clip(RoundedCornerShape(14.dp)).background(p.surface)
            .border(1.dp, p.line, RoundedCornerShape(14.dp)).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Pass messages along", color = p.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(if (Mesh.relay.value) "Your phone is passing messages along." else "Off. Your phone won’t carry others’ messages.",
                        color = p.mute, fontSize = 13.sp)
                }
                Switch(Mesh.relay.value, { Mesh.relay.value = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = p.ok, checkedThumbColor = Color.White))
            }
            Text("Your phone carries other people’s sealed messages onward, even for days until it meets the next phone. It can’t read them or see who they are for. Carrying ${Mesh.carried.value} now.",
                color = p.mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        OutlinedTextField(Mesh.name.value, { Mesh.setMyName(it) }, Modifier.padding(16.dp, 0.dp, 16.dp, 12.dp).fillMaxWidth(),
            singleLine = true, label = { Text("Your name (others see this)", color = p.mute) },
            shape = RoundedCornerShape(12.dp), colors = fieldColors(p))
        Column(Modifier.padding(16.dp, 0.dp, 16.dp, 12.dp).fillMaxWidth()
            .clip(RoundedCornerShape(14.dp)).background(p.surface)
            .border(1.dp, p.line, RoundedCornerShape(14.dp)).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bridge to internet", color = p.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(Gateway.status.value, color = p.mute, fontSize = 13.sp)
                }
                Switch(Gateway.on.value, { Gateway.setOn(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = p.ok, checkedThumbColor = Color.White))
            }
            Text("When this phone has internet, it sends and fetches sealed messages through a relay server so they can cross the world. The relay can’t read them.",
                color = p.mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp))
            OutlinedTextField(Gateway.server.value, { Gateway.setServer(it) }, Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("Relay server", color = p.mute) }, shape = RoundedCornerShape(12.dp),
                colors = fieldColors(p))
        }
        Row(Modifier.padding(16.dp, 0.dp, 16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ showMine = true }, Modifier.weight(1f)) { Text("My code", color = p.accent) }
            OutlinedButton({ showAdd = true }, Modifier.weight(1f)) { Text("Add contact", color = p.accent) }
        }
        if (showMine) {
            val ctx = LocalContext.current
            val clip = LocalClipboardManager.current
            val code = Mesh.myCode()
            AlertDialog(onDismissRequest = { showMine = false },
                containerColor = p.surface, titleContentColor = p.ink, textContentColor = p.mute,
                title = { Text("My code") },
                text = {
                    Column {
                        Text(code, color = p.ink, fontSize = 12.sp)
                        Text("Your ID: ${Crypto.id.take(4)}. Send this code to a friend. They tap Add contact and paste it. Share it only with people you want to message.",
                            modifier = Modifier.padding(top = 10.dp))
                    }
                },
                confirmButton = {
                    TextButton({
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, code), null))
                    }) { Text("Share", color = p.accent) }
                },
                dismissButton = {
                    TextButton({ clip.setText(AnnotatedString(code)); showMine = false }) { Text("Copy", color = p.accent) }
                })
        }
        if (showAdd) {
            var code by remember { mutableStateOf("") }
            var err by remember { mutableStateOf<String?>(null) }
            AlertDialog(onDismissRequest = { showAdd = false },
                containerColor = p.surface, titleContentColor = p.ink, textContentColor = p.mute,
                title = { Text("Add contact") },
                text = {
                    Column {
                        OutlinedTextField(code, { code = it; err = null }, Modifier.fillMaxWidth(),
                            label = { Text("Paste their code", color = p.mute) }, colors = fieldColors(p))
                        err?.let { Text(it, color = p.hop, modifier = Modifier.padding(top = 8.dp)) }
                    }
                },
                confirmButton = {
                    TextButton({ val e = Mesh.addByCode(code); if (e == null) showAdd = false else err = e }) {
                        Text("Add", color = p.accent)
                    }
                },
                dismissButton = { TextButton({ showAdd = false }) { Text("Close", color = p.mute) } })
        }
        Text("Chats", color = p.mute, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(16.dp, 8.dp, 16.dp, 4.dp))
        if (Mesh.contacts.isEmpty())
            Text("No one found yet. Keep the app open near other NearTalk phones.", color = p.mute,
                modifier = Modifier.padding(24.dp))
        Column {
            Mesh.contacts.forEach { c ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(c.id) }.padding(16.dp, 13.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(if (c.hops > 5) p.hop else p.accent, CircleShape),
                        contentAlignment = Alignment.Center) {
                        Text(c.name.take(1).uppercase(), color = if (c.hops > 5) Color.White else p.onAccent,
                            fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = p.ink, fontWeight = FontWeight.SemiBold)
                        val dup = Mesh.contacts.count { it.name == c.name } > 1
                        Text((if (c.id in Mesh.verified) "Verified" else "Not verified") + " · ID ${c.id.take(4)}" +
                            (if (dup) " · same name as another contact" else ""), fontSize = 12.sp,
                            color = if (dup) p.hop else if (c.id in Mesh.verified) p.ok else p.mute)
                    }
                    Text(hopLabel(c.hops), fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, color = if (c.hops == 1) p.ok else p.hop,
                        modifier = Modifier.border(1.dp, p.line, RoundedCornerShape(10.dp)).padding(9.dp, 3.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
            }
        }
    }
}

@Composable
fun Chat(id: String, back: () -> Unit) {
    val p = pal()
    val c = Mesh.contacts.firstOrNull { it.id == id }
    var text by remember { mutableStateOf("") }
    var showCode by remember { mutableStateOf(false) }
    val list = Mesh.msgs.filter { it.peer == id }
    val fmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Column(Modifier.fillMaxWidth().background(p.surface).padding(16.dp, 8.dp, 16.dp, 12.dp)) {
            Text("‹ Chats", color = p.accent, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { back() }.padding(vertical = 6.dp))
            Text(c?.name ?: "Unknown", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Dot(); Spacer(Modifier.width(8.dp))
                Text(if (c == null || c.hops == 1) "Direct Bluetooth link" else if (c.hops == 0) "Remote · mesh or internet bridge" else "Through the mesh · ${c.hops} hops",
                    color = p.mute, fontSize = 13.sp)
            }
            if (c != null) {
                val ver = c.id in Mesh.verified
                Text(if (ver) "Verified ✓  ·  View safety code" else "Not verified  ·  Check safety code",
                    color = if (ver) p.ok else p.hop, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { showCode = true }.padding(top = 6.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            item {
                Text("End-to-end encrypted. Only you and ${c?.name ?: "this person"} can read these messages." +
                    if (c != null && c.hops != 1) " Phones in between pass them along but can’t read them or see who they are for." else "",
                    color = p.mute, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(12.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
            items(list) { m ->
                Box(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Column(Modifier.widthIn(max = 300.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (m.mine) p.mine else p.theirs)
                        .then(if (m.mine) Modifier else Modifier.border(1.dp, p.line, RoundedCornerShape(16.dp)))
                        .padding(12.dp, 9.dp)) {
                        Text(m.text, color = if (m.mine) Color.White else p.ink)
                        Text(fmt.format(Date(m.time)) + if (!m.mine) "" else if (m.delivered) " · Delivered ✓" else if (m.sent) " · Sent, not confirmed yet" else " · Waiting for a phone nearby",
                            color = if (m.mine) Color.White.copy(alpha = .8f) else p.mute,
                            fontSize = 11.5.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        if (showCode && c != null) {
            val ver = c.id in Mesh.verified
            AlertDialog(onDismissRequest = { showCode = false },
                containerColor = p.surface, titleContentColor = p.ink, textContentColor = p.mute,
                title = { Text("Safety code") },
                text = {
                    Column {
                        Text(Crypto.safetyCode(c.key), color = p.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Compare this code with ${c.name} (ID ${c.id.take(4)}) in person or on a voice call. If it matches on both phones, nobody is in the middle.",
                            modifier = Modifier.padding(top = 10.dp))
                    }
                },
                confirmButton = {
                    TextButton({ Mesh.setVerified(c.id, !ver); showCode = false }) {
                        Text(if (ver) "Mark as not verified" else "It matches", color = p.accent)
                    }
                },
                dismissButton = { TextButton({ showCode = false }) { Text("Close", color = p.mute) } })
        }
        Row(Modifier.fillMaxWidth().background(p.surface).padding(12.dp, 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), shape = RoundedCornerShape(22.dp),
                placeholder = { Text("Message over Bluetooth", color = p.mute) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = p.ink, unfocusedTextColor = p.ink,
                    focusedBorderColor = p.accent, unfocusedBorderColor = p.line, cursorColor = p.accent,
                    focusedContainerColor = p.bg, unfocusedContainerColor = p.bg))
            Spacer(Modifier.width(8.dp))
            Button({ if (c != null && text.isNotBlank()) { Mesh.sendText(c, text.trim()); text = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent)) { Text("Send") }
        }
    }
}
