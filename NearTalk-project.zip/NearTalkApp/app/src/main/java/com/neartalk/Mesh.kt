package com.neartalk

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.Callable
import java.util.concurrent.FutureTask

/** hops: 1 = direct, 0 = not known yet (heard only through a message). */
data class Contact(val id: String, val name: String, val key: String, val hops: Int)
data class Msg(val peer: String, val mine: Boolean, val text: String, val time: Long = System.currentTimeMillis(),
               val pid: String = "", val sent: Boolean = true, val delivered: Boolean = false)

/**
 * Mesh over Nearby Connections (Bluetooth + Wi-Fi Direct, no internet) with store-and-forward.
 * - Packets are kept on the phone (encrypted at rest) for up to 7 days and survive restarts.
 * - When two phones meet they swap lists of packet ids, then send only what the other is missing.
 * - So a message can ride along with people as they move, and reach places the live mesh never touches.
 * Message packets carry only: id, time, hop limit, one-time key, ciphertext. Relays can't see who they are for.
 */
object Mesh {
    private const val SERVICE = "com.neartalk.mesh"
    private const val TTL = 100
    private const val MSG_AGE = 7 * 86_400_000L
    private const val HELLO_AGE = 86_400_000L
    private const val CACHE_MAX = 500

    private lateinit var ctx: Context
    val name = mutableStateOf(Build.MODEL)
    private val myName get() = name.value.trim().ifEmpty { Build.MODEL }
    private var started = false
    private val handler = Handler(Looper.getMainLooper())
    private val saver = Runnable { save() }

    val linked = mutableStateOf(0)
    val carried = mutableStateOf(0)
    val relay = mutableStateOf(true)
    val contacts = mutableStateListOf<Contact>()
    val msgs = mutableStateListOf<Msg>()
    val verified = mutableStateListOf<String>()

    private val links = mutableSetOf<String>()
    private val seen = LinkedHashSet<String>()
    private val cache = ArrayDeque<JSONObject>()
    private val uploaded = LinkedHashMap<String, Long>()   // packet id -> when it was last uploaded

    private val client get() = Nearby.getConnectionsClient(ctx)
    private fun me() = "${Crypto.id}|$myName"
    private fun prefs() = ctx.getSharedPreferences("mesh", Context.MODE_PRIVATE)
    private fun file() = File(ctx.filesDir, "state.bin")

    fun attach(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        name.value = prefs().getString("name", Build.MODEL) ?: Build.MODEL
        verified.addAll(prefs().getStringSet("ver", emptySet()) ?: emptySet())
        load()
        prune()
    }

    fun setMyName(n: String) {
        val v = n.take(24)
        name.value = v
        prefs().edit().putString("name", v.trim()).apply()
    }

    fun setVerified(id: String, on: Boolean) {
        if (on) { if (id !in verified) verified.add(id) } else verified.remove(id)
        prefs().edit().putStringSet("ver", verified.toSet()).apply()
    }

    // ---------- saved state (encrypted with an Android Keystore key) ----------
    private fun saveSoon() { handler.removeCallbacks(saver); handler.postDelayed(saver, 2000) }

    private fun save() {
        try {
            val o = JSONObject()
            o.put("cache", JSONArray(cache.toList()))
            o.put("seen", JSONArray(seen.toList().takeLast(2000)))
            val up = JSONObject()
            uploaded.entries.toList().takeLast(1000).forEach { up.put(it.key, it.value) }
            o.put("up", up)
            o.put("contacts", JSONArray(contacts.map {
                JSONObject().put("id", it.id).put("name", it.name).put("key", it.key).put("hops", it.hops) }))
            o.put("msgs", JSONArray(msgs.map {
                JSONObject().put("peer", it.peer).put("mine", it.mine).put("text", it.text)
                    .put("time", it.time).put("pid", it.pid).put("sent", it.sent).put("delivered", it.delivered) }))
            file().writeBytes(Crypto.wrap(o.toString().toByteArray()))
        } catch (_: Exception) {}
    }

    private fun load() {
        try {
            val f = file(); if (!f.exists()) return
            val o = JSONObject(String(Crypto.unwrap(f.readBytes()) ?: return))
            o.getJSONArray("cache").let { a -> for (i in 0 until a.length()) cache.addLast(a.getJSONObject(i)) }
            o.optJSONObject("up")?.let { u -> u.keys().forEach { k -> uploaded[k] = u.getLong(k) } }
            o.getJSONArray("seen").let { a -> for (i in 0 until a.length()) seen.add(a.getString(i)) }
            o.getJSONArray("contacts").let { a -> for (i in 0 until a.length()) {
                val c = a.getJSONObject(i)
                contacts.add(Contact(c.getString("id"), c.getString("name"), c.getString("key"), c.getInt("hops"))) } }
            o.getJSONArray("msgs").let { a -> for (i in 0 until a.length()) {
                val m = a.getJSONObject(i)
                msgs.add(Msg(m.getString("peer"), m.getBoolean("mine"), m.getString("text"), m.getLong("time"),
                    m.optString("pid"), m.optBoolean("sent", true), m.optBoolean("delivered", false))) } }
        } catch (_: Exception) {}
    }

    // ---------- starting ----------
    fun start(c: Context, name: String) {
        if (started) return
        started = true
        attach(c)
        client.startAdvertising(me(), SERVICE, lifecycle,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
        client.startDiscovery(SERVICE, discovery,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
    }

    private fun freshHello(): JSONObject {
        val key = Crypto.b64(Crypto.pub.encoded)
        return JSONObject().put("id", UUID.randomUUID().toString()).put("t", "hello")
            .put("ttl", TTL).put("t0", System.currentTimeMillis())
            .put("from", Crypto.id).put("name", myName).put("key", key)
            .put("sig", Crypto.sign("hello|$myName|$key"))
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(e: String, i: DiscoveredEndpointInfo) {
            // Only the phone with the smaller id asks, so two phones don't both connect at once.
            val rid = i.endpointName.substringBefore("|")
            if (Crypto.id < rid && e !in links) client.requestConnection(me(), e, lifecycle)
        }
        override fun onEndpointLost(e: String) {}
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(e: String, i: ConnectionInfo) {
            client.acceptConnection(e, receiver)
        }
        override fun onConnectionResult(e: String, r: ConnectionResolution) {
            if (!r.status.isSuccess) return
            links.add(e); linked.value = links.size
            prune()
            val h = freshHello()
            seen.add(h.getString("id"))
            remember(h)
            sendInventory(e)                                        // "here is what I carry"
            links.filter { it != e }.forEach { send(it, h) }        // tell others about the new link
        }
        override fun onDisconnected(e: String) { links.remove(e); linked.value = links.size }
    }

    private val receiver = object : PayloadCallback() {
        override fun onPayloadReceived(e: String, p: Payload) {
            val b = p.asBytes() ?: return
            try { handle(JSONObject(String(b)), e) } catch (_: Exception) {}
        }
        override fun onPayloadTransferUpdate(e: String, u: PayloadTransferUpdate) {}
    }

    // ---------- store and forward ----------
    private fun sendInventory(e: String) {
        val ids = cache.map { it.getString("id") }.takeLast(500)
        send(e, JSONObject().put("t", "inv").put("ids", JSONArray(ids)))
    }

    private fun expired(j: JSONObject): Boolean {
        val now = System.currentTimeMillis()
        val age = if (j.getString("t") == "msg") MSG_AGE else HELLO_AGE
        return now - j.optLong("t0", now) > age
    }

    private fun prune() {
        cache.removeAll { expired(it) }
        carried.value = cache.size
    }

    private fun remember(j: JSONObject) {
        if (j.getString("t") == "hello")
            cache.removeAll { it.getString("t") == "hello" && it.optString("from") == j.optString("from") }
        cache.addLast(j)
        while (cache.size > CACHE_MAX) cache.removeFirst()
        carried.value = cache.size
        saveSoon()
    }

    private fun markSent(pid: String) {
        val i = msgs.indexOfFirst { it.pid == pid && !it.sent }
        if (i >= 0) { msgs[i] = msgs[i].copy(sent = true); saveSoon() }
    }

    // ---------- receiving ----------
    private fun upsert(id: String, name: String, key: String, hops: Int) {
        val i = contacts.indexOfFirst { it.id == id }
        if (i < 0) { contacts.add(Contact(id, name, key, hops)); saveSoon(); return }
        val o = contacts[i]
        val nh = if (hops > 0 && (o.hops == 0 || hops < o.hops)) hops else o.hops
        if (nh != o.hops || name != o.name) { contacts[i] = o.copy(name = name, hops = nh); saveSoon() }
    }

    private fun handle(j: JSONObject, from: String) {
        val t = j.getString("t")
        if (t == "inv") {
            val a = j.getJSONArray("ids"); val want = JSONArray()
            for (i in 0 until a.length()) { val id = a.getString(i); if (id !in seen) want.put(id) }
            if (want.length() > 0) send(from, JSONObject().put("t", "want").put("ids", want))
            return
        }
        if (t == "want") {
            val a = j.getJSONArray("ids"); val ids = HashSet<String>()
            for (i in 0 until a.length()) ids.add(a.getString(i))
            cache.filter { it.getString("id") in ids }.forEach { send(from, it); markSent(it.getString("id")) }
            return
        }
        if (!seen.add(j.getString("id"))) return
        if (seen.size > 2000) seen.remove(seen.first())
        if (expired(j)) return
        when (t) {
            "hello" -> {
                val key = j.getString("key"); val name = j.getString("name"); val sender = j.getString("from")
                if (Crypto.idOf(Crypto.b64d(key)) != sender) return
                if (!Crypto.verify(key, "hello|$name|$key", j.getString("sig"))) return
                if (sender != Crypto.id) upsert(sender, name, key, TTL - j.getInt("ttl") + 1)
            }
            "msg" -> {
                val o = Crypto.open(j.getString("e"), j.getString("c"))
                if (o != null) {                                    // it was for us: stop here
                    val sender = Crypto.idOf(Crypto.b64d(o.senderKey))
                    upsert(sender, o.name, o.senderKey, 0)
                    if (o.ack != null) markDelivered(o.ack)         // a receipt for something we sent
                    else {
                        msgs.add(Msg(sender, false, o.text))
                        saveSoon()
                        notifyNew(o.name)
                        sendReceipt(o.senderKey, sender, j.getString("id"))
                    }
                    return
                }
            }
            else -> return
        }
        forward(j, from)
    }

    private fun forward(j: JSONObject, from: String) {
        val ttl = j.getInt("ttl")
        if (ttl <= 0 || !relay.value) return
        j.put("ttl", ttl - 1)
        remember(j)
        links.filter { it != from }.forEach { send(it, j) }
    }

    private fun send(e: String, j: JSONObject) {
        client.sendPayload(e, Payload.fromBytes(j.toString().toByteArray()))
    }

    private fun notifyNew(name: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26)
                nm.createNotificationChannel(NotificationChannel("msgs", "Messages", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(name.hashCode(), NotificationCompat.Builder(ctx, "msgs")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("New message").setContentText("From $name")
                .setContentIntent(open).setAutoCancel(true).build())
        } catch (_: Exception) {}
    }

    // ---------- sending ----------
    private fun packet(toId: String, e: String, c: String) =
        JSONObject().put("id", UUID.randomUUID().toString()).put("t", "msg")
            .put("ttl", TTL).put("t0", System.currentTimeMillis()).put("e", e).put("c", c)
            .put("b", bucketOf(toId))

    /** Sealed receipt sent back along every route (mesh, carried, internet) so the sender knows it arrived. */
    private fun sendReceipt(key: String, toId: String, pid: String) {
        val (e, c) = Crypto.seal(key, myName, "", pid)
        val j = packet(toId, e, c)
        seen.add(j.getString("id"))
        remember(j)
        links.forEach { send(it, j) }
    }

    private fun markDelivered(pid: String) {
        val i = msgs.indexOfFirst { it.pid == pid }
        if (i >= 0 && !msgs[i].delivered) msgs[i] = msgs[i].copy(sent = true, delivered = true)
        cache.removeAll { it.getString("id") == pid }       // stop spreading it, it has arrived
        carried.value = cache.size
        saveSoon()
    }

    fun sendText(to: Contact, text: String) {
        val (e, c) = Crypto.seal(to.key, myName, text)
        val j = packet(to.id, e, c)
        seen.add(j.getString("id"))
        msgs.add(Msg(to.id, true, text, pid = j.getString("id"), sent = links.isNotEmpty()))
        remember(j)                                   // kept on the phone until someone can take it
        links.forEach { send(it, j) }
    }

    // ---------- contacts by code, and the internet bridge ----------
    /** One of 64 groups. The relay server sees only this number, never who a message is for. */
    private fun bucketOf(id: String) = id.substring(0, 2).toInt(16) % 64

    fun myCode() = "NT1:${myName.replace(":", " ")}:${Crypto.b64(Crypto.pub.encoded)}"

    /** Returns an error message, or null when the contact was added. */
    fun addByCode(code: String): String? {
        val p = code.trim().split(":", limit = 3)
        if (p.size != 3 || p[0] != "NT1") return "That isn’t a NearTalk code."
        return try {
            if (!Crypto.validKey(p[2])) return "That code is damaged."
            val id = Crypto.idOf(Crypto.b64d(p[2]))
            if (id == Crypto.id) "That is your own code." else { upsert(id, p[1], p[2], 0); null }
        } catch (e: Exception) { "That code is damaged." }
    }

    private fun <T> onMain(f: () -> T): T {
        val t = FutureTask<T>(Callable<T> { f() })
        handler.post(t)
        return t.get()
    }

    /** Called from the bridge's background thread. */
    fun snapshotForGateway(): Pair<List<JSONObject>, Set<Int>> = onMain {
        val now = System.currentTimeMillis()
        val retry = msgs.filter { it.mine && !it.delivered }.map { it.pid }.toSet()
        val pending = cache.filter {
            val id = it.getString("id")
            it.getString("t") == "msg" && it.has("b") &&
                (id !in uploaded || (id in retry && now - (uploaded[id] ?: 0L) > 6 * 3_600_000L))
        }.takeLast(30).map { JSONObject(it.toString()) }
        val buckets = (contacts.map { bucketOf(it.id) } + bucketOf(Crypto.id)).toSet()
        Pair(pending, buckets)
    }

    fun markUploaded(id: String) {
        uploaded[id] = System.currentTimeMillis()
        val i = msgs.indexOfFirst { it.pid == id && !it.sent }
        if (i >= 0) msgs[i] = msgs[i].copy(sent = true)
        saveSoon()
    }

    fun fromInternet(j: JSONObject) {
        try { if (j.getString("t") == "msg") handle(j, "internet") } catch (_: Exception) {}
    }
}
