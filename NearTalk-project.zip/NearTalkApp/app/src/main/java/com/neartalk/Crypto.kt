package com.neartalk

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.math.BigInteger
import java.security.*
import java.security.spec.*
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class Opened(val senderKey: String, val name: String, val text: String, val ack: String?)

/**
 * End-to-end encryption.
 * - Identity: one P-256 key pair per phone. The private key is stored encrypted with an Android Keystore key.
 * - Message = two layers. Inner layer: AES-GCM key from ECDH(sender key, recipient key), which proves who sent it.
 *   Outer layer: AES-GCM key from ECDH(fresh one-time key, recipient key), which hides sender, recipient and name from relays.
 * - Relays see only a random one-time key and ciphertext. A phone finds its own messages by trying to open each one.
 */
object Crypto {
    lateinit var pub: PublicKey
    private lateinit var priv: PrivateKey
    lateinit var id: String

    fun init(c: Context) {
        if (::pub.isInitialized) return
        val sp = c.getSharedPreferences("keys", Context.MODE_PRIVATE)
        val kf = KeyFactory.getInstance("EC")
        val p = sp.getString("pub", null)
        val raw = sp.getString("wpriv", null)?.let { unwrap(b64d(it)) }
        if (p != null && raw != null) {
            pub = kf.generatePublic(X509EncodedKeySpec(b64d(p)))
            priv = kf.generatePrivate(PKCS8EncodedKeySpec(raw))
        } else {
            val kp = newKeyPair()
            pub = kp.public; priv = kp.private
            sp.edit().remove("priv").putString("pub", b64(pub.encoded))
                .putString("wpriv", b64(wrap(priv.encoded))).apply()
        }
        id = idOf(pub.encoded)
    }

    fun idOf(k: ByteArray) =
        MessageDigest.getInstance("SHA-256").digest(k).take(6).joinToString("") { "%02x".format(it) }

    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun b64d(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    // ---- private key at rest ----
    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        (ks.getKey("nt_wrap", null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder("nt_wrap", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return g.generateKey()
    }
    fun wrap(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, wrapKey())
        return c.iv + c.doFinal(b)
    }
    fun unwrap(d: ByteArray): ByteArray? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, d.copyOfRange(0, 12)))
        c.doFinal(d, 12, d.size - 12)
    } catch (e: Exception) { null }

    // ---- primitives ----
    private fun newKeyPair(): KeyPair {
        val g = KeyPairGenerator.getInstance("EC"); g.initialize(ECGenParameterSpec("secp256r1"))
        return g.generateKeyPair()
    }
    private fun ecdh(mine: PrivateKey, theirPub: ByteArray): ByteArray {
        val peer = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(theirPub))
        val ka = KeyAgreement.getInstance("ECDH"); ka.init(mine); ka.doPhase(peer, true)
        return ka.generateSecret()
    }
    private fun kdf(label: String, secret: ByteArray, context: ByteArray) =
        SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(label.toByteArray() + secret + context), "AES")
    private fun enc(k: SecretKeySpec, pt: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        return iv + c.doFinal(pt)
    }
    private fun dec(k: SecretKeySpec, d: ByteArray): ByteArray? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, d.copyOfRange(0, 12)))
        c.doFinal(d, 12, d.size - 12)
    } catch (e: Exception) { null }

    fun validKey(k: String): Boolean = try {
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(b64d(k))); true
    } catch (e: Exception) { false }

    // ---- messages ----
    /** Returns (one-time public key, ciphertext). */
    fun seal(recipientKey: String, name: String, text: String, ack: String? = null): Pair<String, String> {
        val rp = b64d(recipientKey); val sp = pub.encoded
        val k2 = kdf("nt-inner", ecdh(priv, rp), sp + rp)
        val body = JSONObject().put("n", name).put("t", text)
        if (ack != null) body.put("a", ack)
        val inner = enc(k2, body.toString().toByteArray())
        val outerPlain = JSONObject().put("k", b64(sp)).put("b", b64(inner)).toString().toByteArray()
        val eph = newKeyPair(); val ep = eph.public.encoded
        val k1 = kdf("nt-outer", ecdh(eph.private, rp), ep + rp)
        return Pair(b64(ep), b64(enc(k1, outerPlain)))
    }

    /** Null if this message is not for us, or was tampered with. */
    fun open(e: String, c: String): Opened? {
        try {
            val ep = b64d(e); val rp = pub.encoded
            val k1 = kdf("nt-outer", ecdh(priv, ep), ep + rp)
            val outer = JSONObject(String(dec(k1, b64d(c)) ?: return null))
            val sk = outer.getString("k"); val sp = b64d(sk)
            val k2 = kdf("nt-inner", ecdh(priv, sp), sp + rp)
            val inner = JSONObject(String(dec(k2, b64d(outer.getString("b"))) ?: return null))
            return Opened(sk, inner.getString("n"), inner.getString("t"), inner.optString("a").ifEmpty { null })
        } catch (x: Exception) { return null }
    }

    // ---- announcements ----
    fun sign(data: String): String {
        val s = Signature.getInstance("SHA256withECDSA"); s.initSign(priv); s.update(data.toByteArray())
        return b64(s.sign())
    }
    fun verify(keyB64: String, data: String, sig: String): Boolean = try {
        val s = Signature.getInstance("SHA256withECDSA")
        s.initVerify(KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(b64d(keyB64))))
        s.update(data.toByteArray()); s.verify(b64d(sig))
    } catch (e: Exception) { false }

    /** Same code on both phones. If it matches when compared in person or by voice, nobody is in the middle. */
    fun safetyCode(theirKey: String): String {
        val a = pub.encoded; val b = b64d(theirKey)
        val (x, y) = if (b64(a) < b64(b)) Pair(a, b) else Pair(b, a)
        val h = MessageDigest.getInstance("SHA-256").digest(x + y)
        return BigInteger(1, h).toString().padStart(78, '0').take(30).chunked(5).joinToString(" ")
    }
}
