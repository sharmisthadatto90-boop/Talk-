package com.neartalk

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Internet bridge. While this phone has internet it:
 *  1. uploads sealed message packets it carries to a relay server (an ntfy server, public or your own), and
 *  2. downloads sealed packets addressed to anyone it knows (itself and its contacts) and feeds them into the local mesh.
 * Packets stay end-to-end encrypted. The relay only sees sealed data, the phone's IP address, timing, and a 1-of-64 group number.
 */
object Gateway {
    val on = mutableStateOf(true)
    val server = mutableStateOf("https://ntfy.sh")
    val status = mutableStateOf("Waiting for internet")

    private lateinit var ctx: Context
    private val main = Handler(Looper.getMainLooper())
    private var running = false

    private fun prefs() = ctx.getSharedPreferences("gateway", Context.MODE_PRIVATE)

    fun attach(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        on.value = prefs().getBoolean("on", true)
        server.value = prefs().getString("server", "https://ntfy.sh") ?: "https://ntfy.sh"
    }

    fun setOn(v: Boolean) { on.value = v; prefs().edit().putBoolean("on", v).apply() }
    fun setServer(s: String) { server.value = s; prefs().edit().putString("server", s).apply() }

    fun start(c: Context) {
        attach(c)
        if (running) return
        running = true
        Executors.newSingleThreadScheduledExecutor().scheduleWithFixedDelay({
            try { tick() } catch (e: Exception) { setStatus("Problem: ${e.javaClass.simpleName}") }
        }, 5, 60, TimeUnit.SECONDS)
    }

    private fun setStatus(s: String) { main.post { status.value = s } }

    private fun online(): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun topic(b: Int) = "neartalk-v1-$b"
    private fun base() = server.value.trim().trimEnd('/')

    private fun tick() {
        if (!on.value) { setStatus("Off"); return }
        if (!online()) { setStatus("Waiting for internet"); return }
        val (pending, buckets) = Mesh.snapshotForGateway()
        var up = 0
        for (j in pending) {
            if (!post(topic(j.getInt("b")), j.toString())) { setStatus("Relay server is not accepting messages"); return }
            val id = j.getString("id")
            main.post { Mesh.markUploaded(id) }
            up++
        }
        val n = download(buckets)
        setStatus("Online · sent $up, received $n")
    }

    private fun post(topic: String, body: String): Boolean {
        val c = URL("${base()}/$topic").openConnection() as HttpURLConnection
        return try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 15000
            c.outputStream.use { it.write(body.toByteArray()) }
            c.responseCode in 200..299
        } finally { c.disconnect() }
    }

    private fun download(buckets: Set<Int>): Int {
        val set = buckets.sorted().joinToString(",")
        // New contact = new group to read, so look back over everything the server still holds.
        if (prefs().getString("bset", "") != set) prefs().edit().putString("bset", set).putString("since", "all").apply()
        val since = prefs().getString("since", "all")
        val topics = buckets.sorted().joinToString(",") { topic(it) }
        val c = URL("${base()}/$topics/json?poll=1&since=$since").openConnection() as HttpURLConnection
        var count = 0
        var latest = 0L
        try {
            c.connectTimeout = 15000; c.readTimeout = 20000
            if (c.responseCode !in 200..299) return 0
            c.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    try {
                        val m = JSONObject(line)
                        if (m.optString("event") == "message") {
                            latest = maxOf(latest, m.optLong("time"))
                            val pkt = JSONObject(m.getString("message"))
                            count++
                            main.post { Mesh.fromInternet(pkt) }
                        }
                    } catch (_: Exception) {}
                }
            }
        } finally { c.disconnect() }
        if (latest > 0) prefs().edit().putString("since", (latest + 1).toString()).apply()
        return count
    }
}
