# NearTalk

Offline chat for Android. Messages hop phone to phone over Bluetooth and Wi-Fi Direct. No internet.

## Get the APK without Android Studio (GitHub)
1. Create a free account at github.com and make a new repository.
2. Upload everything in this folder, including the hidden `.github` folder. Use "Add file > Upload files" and drag the unzipped folder contents in.
3. Open the repository's Actions tab. The "Build APK" run starts by itself (or press "Run workflow"). It takes about 5 minutes.
4. Open the finished run and download `NearTalk-apk`. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone and open it. Allow "Install unknown apps" when asked.

## Or use Android Studio
Open this folder, let it sync, then Build > Build APK(s). The file is in `app/build/outputs/apk/debug/`.

## Using it
Install on at least two Android phones, open the app, accept the permissions and leave it running. The phones find each other. Keep Bluetooth, Wi-Fi and location switched on (no internet needed). Only phones with NearTalk can pass messages along.

## Finding the person to message
- Set "Your name" on the home screen. Nearby people appear in your list by the name they set.
- Far away people: tap "My code", send it to them in any chat app, and ask for theirs. Tap "Add contact" and paste it.
- Every contact shows a 4-character ID. If two contacts have the same name, the app warns you. Use the ID and the safety code (open the chat, tap "Check safety code") to be sure it is the right person.

## How the routes work together
A message is sent along all routes at once: to phones nearby right now, kept on your phone for up to 7 days to hand to phones you meet later, and uploaded through any phone with internet. The first copy to arrive wins and duplicates are dropped. The receiver sends back a sealed receipt along the same routes, and the message then shows "Delivered ✓". Until then, the internet upload is repeated every 6 hours.

## Internet bridge (messages across the world)
- When a phone has internet, it uploads sealed messages it carries to a relay server and downloads sealed messages for itself and its contacts. It then passes them into its local mesh. So a phone with no signal can still send to another country through any phone nearby that has signal.
- The relay is an ntfy server. The default is the public one at https://ntfy.sh. Public servers limit how much one phone can send and keep messages only for about 12 hours. For more use, run your own ntfy server (free, open source) and type its https address into "Relay server".
- The relay can't read messages. It sees the phone's IP address, timing, message size, and a group number from 1 to 64 (not who the message is for). Phones in the mesh also see that group number.
- People far away don't appear on their own, because announcements only travel through the local mesh. To message someone far away, tap "My code" and send it to them (any chat app). They tap "Add contact" and paste it, and you do the same with theirs.
- Switch the bridge off in the app if you don't want to use mobile data.

## Delivery by people moving around
- A message waits on your phone until it meets another NearTalk phone. Then it is handed over, and that phone hands it on when it meets others.
- Messages are kept for up to 7 days and survive restarts. They are stored encrypted.
- Two phones that meet swap lists of what they carry and send only what the other is missing, so little data is used.
- You get a "New message" notification when one arrives. It shows only the sender's name.
- Delivery depends on people actually travelling between places. It can take hours or days, and it is not guaranteed.

## Security (what is protected)
- Messages are end-to-end encrypted. Only the recipient's phone can open them.
- Relay phones can't read a message, and can't see who sent it or who it is for.
- Each phone's private key is stored encrypted with an Android Keystore key.
- Announcements (name and public key) are signed, so relays can't alter them.
- To be sure you are talking to the right person, open the chat, tap "Check safety code" and compare the code with them in person or by voice. Tap "It matches" to mark them verified.

What is not protected: your name is visible to nearby phones while the app is on, and relays can see that packets exist and how big they are. There is no forward secrecy (if a phone's key is stolen, messages saved from earlier could be opened) and no protection against replayed messages. This code has not been security audited, so don't use it where lives depend on it.

## Known limits
There are no delivery receipts, group chats or LoRa support yet. Some phone makers stop background apps; turn off battery optimisation for NearTalk. I couldn't compile this here, so expect small fixes on first build.
